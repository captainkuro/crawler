<?php
require 'crawler.php';
/*
$f = file_get_contents('http://javupdate.com/gallery/archives/graphis/Ai_Sayama/ai-s201_20100518010324/ai-s201/');
$l = Crawler::extract_to_array($f, '<a href="', '"');
print_r($l);
*/

function recurse($url) {
	echo "Currently $url\n";flush();
	$s = file_get_contents($url);
	$r = array();
	$l = Crawler::extract_to_array($s, '<a href="', '"');
	$n = count($l);
	for ($i=5; $i<$n; $i++) {
		if (strrpos($l[$i], '/') == (strlen($l[$i])-1)) {
			$r[$l[$i]] = recurse($url . $l[$i]);
		} else {
			$r[$l[$i]] = $l[$i];
		}
	}
	return $r;
}

//$h = recurse('http://javupdate.com/gallery/archives/graphis/');
//$h = Crawler::explore('http://glam0ur.com/gals/penny_mathis/', '<A HREF="', '"', 5);
//$h = Crawler::explore('http://kk5fnb765tfgr4.av-girl.info/beauty/', '<a href="', '"', 5);
/*
for ($i=2007; $i<=2010; ++$i) {
	$h[$i] = Crawler::explore('http://www.emmawatson4u.com/wp-content/uploads/' . $i . '/', '<a href="', '"', 1);
}
*/
$h = Crawler::explore('http://www.itcute.com/wp-content/uploads/', '<a href="', '"', 1);
?>

<?php var_export($h); ?>
