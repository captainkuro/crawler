<?php
require 'crawler.php';

function recurse($prefix, $item, $name) {
	foreach ($item as $key => $val) {
		if (is_array($val)) {
			if (strpos($key, 'thumb') === false) {
				recurse($prefix.$key, $val, $name);
			}
		} else {
			echo '<a href="'.$prefix.$key.'">'.$name.'</a><br/>'."\n";flush();
		}
	}
}

function recurse2($prefix, $item, $name) {
	foreach ($item as $key => $val) {
		if (is_array($val)) {
			//if (strpos($key, 'thumb') === false) {
				recurse2($prefix.$key, $val, $name);
			//}
		} else if (strpos($key, 's') !== 0) {
			$name = basename($prefix);
			echo '<a href="'.$prefix.$key.'">'.$name.'</a><br/>'."\n";flush();
		}
	}
}

//require 'jaxupdate.hasil.txt';	// dapet $a
require 'av-girl.info.txt';	// dapet $a

foreach ($a as $name => $el) {
	//recurse('http://javupdate.com/gallery/archives/graphis/'.$name, $el, $name);
	recurse2('http://kk5fnb765tfgr4.av-girl.info/beauty/'.$name, $el, $name);
}

//recurse('http://kk5fnb765tfgr4.av-girl.info/beauty/', $a);